

/**
 *
 * @author motion411
 */
package AutoGephi;

public class Main 
{
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        
        
        AutoGephiPipeV3.initialize();
        try{
            AutoGephiPipeV3.importDirectory(args[0]);
        }
        catch(Exception e){
            System.out.println("Failed Import");
            e.printStackTrace();
        }
        System.out.println("Reached End of Directory Loop");
        try{
            AutoGephiPipeV3.setSizeNodesBy("Betweenness");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        System.out.println("SET SIZE PARAMETER");
        try{
            AutoGephiPipeV3.sizeNodes();
        }
        catch(Exception e){
            System.out.println("Error, Could Not Size Nodes");
            e.printStackTrace();
        }
        System.out.println("SIZED NODES");
        
        try{
            AutoGephiPipeV3.colorByCommunity();
        }
        catch(Exception e){
            System.out.println("Error, Could Not Color by Community");
            e.printStackTrace();
        }
        System.out.println("Colored by Community");
        try{
            AutoGephiPipeV3.circularStarLayout();
        }
        catch(Exception e){
            System.out.println("Error, Could Not Perform Layout");
            e.printStackTrace();
        }
        System.out.println("STAR LAYOUT");
        try{
            AutoGephiPipeV3.exportGraph();
        }
        catch(Exception e){
            System.out.println("Error, Could Not Export Graph");
            e.printStackTrace();
        }
        System.out.println("FILE EXPORTED");
        try{
            AutoGephiPipeV3.exportDates();
        }
        catch(Exception e){
            System.out.println("Error, Could Not Export Dates");
            e.printStackTrace();
        }
        
        
        
        
        
        
       
    }
    
    
}
