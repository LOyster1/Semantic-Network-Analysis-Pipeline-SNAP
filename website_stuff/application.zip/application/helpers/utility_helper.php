<?php
function asset_url(){
	return base_url().'assets/';
}
?>
