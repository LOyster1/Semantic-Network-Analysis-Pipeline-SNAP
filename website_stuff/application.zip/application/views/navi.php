<ul id="nav">

	<li class="menuItem"><a href="<?php echo site_url(); ?>/home">Home</a></li>
	<li class="menuItem"><a href="<?php echo site_url(); ?>/raw_uploads">Raw Uploads</a></li>
	<li class="menuItem"><a href="<?php echo site_url(); ?>/preprocessed_uploads">Preprocessed Uploads</a></li>
	<li class="menuItem"><a href="semantic">Semantic Networks</a></li>
	<li class="menuItem"><a href="<?php echo site_url(); ?>/home/logout">Logout</a></li>
</ul>
<?php /*Navigation bar at the top of every page */ ?>