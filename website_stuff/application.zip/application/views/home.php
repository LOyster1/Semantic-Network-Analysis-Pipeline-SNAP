<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<!--<link rel="stylesheet" href="/website_stuff/assets/css/menuStyle.css" type="text/css" /> --!>
	<link rel="stylesheet" href="<?php echo asset_url();?>css/menuStyle.css" type="text/css" />
	<title>Home Page</title>
</head>
<body>
	<?php include 'navi.php'; ?>
	<h1>Home</h1>
	<h2>Welcome <?php echo $firstName; echo $file_dir; ?></h2><br/>
</body>
</html>
